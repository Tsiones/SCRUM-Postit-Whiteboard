import React from 'react';
import ReactDOM from 'react-dom';
import PostItContainer from './components/post-it-container';

const myTodoList = (
  <div>
    <PostItContainer />
  </div>
);

ReactDOM.render(myTodoList, document.querySelector('#application'));
